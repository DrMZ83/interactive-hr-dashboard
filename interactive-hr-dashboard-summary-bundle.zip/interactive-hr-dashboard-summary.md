Interactive HR Dashboard - Final Professional Edition
All Capabilities: Auth, Analytics, Roles, Logs, Metrics, History, Read-only UI, Permissions, Team Dashboards, CI/CD, Onboarding, Dark Mode

✅ GitHub Badges
[![Build Status](https://github.com/your-username/interactive-hr-dashboard/actions/workflows/deploy.yml/badge.svg)](https://github.com/your-username/interactive-hr-dashboard/actions)
[![MIT License](https://img.shields.io/badge/license-MIT-green.svg)](LICENSE)
[![Stars](https://img.shields.io/github/stars/your-username/interactive-hr-dashboard?style=social)](https://github.com/your-username/interactive-hr-dashboard)

✅ Team-based Permissions Scaffold (Live)
- User role and department filtering from Firestore `user_settings`
- Team members access /team route, Admins access /dashboard

✅ GitHub-Deployable with Firebase Hosting
- Includes .firebaserc and firebase.json

✅ GitHub Actions CI/CD Workflow
- .github/workflows/deploy.yml → deploys to Firebase on push to main
- Auto previews enabled using deploy channels
- Secrets handled via `FIREBASE_SERVICE_ACCOUNT`

✅ Firebase Client Setup (lib/firebase.js) — uses .env.local with VITE_ vars

✅ Onboarding Modal (for first login)
✅ Dark Mode Toggle (Tailwind-ready)

✅ 🔔 Optional Add-ons Activated

✅ .gitignore file included to exclude node_modules, envs, build, Firebase secrets, etc.
node_modules
.env*
build
dist
firebase-debug.log
firebase-service-account.json

✅ GitHub Preview Channels
Firebase Hosting supports preview channels via GitHub Actions.
No setup needed — branches automatically get preview links like:
https://main--interactive-hr-dashboard.web.app
https://feature-branch-name--interactive-hr-dashboard.web.app

✅ 🧭 Deployment Guide (DEPLOY_GUIDE.md)
(see deploy scripts or README for exact steps)

✅ docs/ Folder (Optional GitHub Pages Documentation)
- index.md
- deployment.md
- features.md
- api.md

✅ All dependencies installed, including @vitejs/plugin-react
